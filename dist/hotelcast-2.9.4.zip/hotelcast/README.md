# Krishna Cloud TV Management — digital signage & TV management SaaS

> Product name: **Krishna Cloud TV Management** (until 2.4: "Krishna Cloud LED TV"). "HotelCast" remains the
> internal code name (folder `hotelcast/`, Android package `com.hotelcast.tv`, database tables `hotels` / `rooms`,
> API fields `hotel_id` / `room_number`). Changing those would break updates of TVs that are already installed —
> see [docs/modules/terminology.md](docs/modules/terminology.md) for the UI term ↔ database / API name mapping.

Control every Android TV, Smart-TV browser and display of a business from one browser tab — temples, shops,
showrooms, restaurants, hospitals and clinics, schools, offices, factories and hotels. When a TV is switched on,
the app opens full-screen and shows whatever the admin has pushed — **live darshan**, **timetables**, menus,
**announcements**, **offers**, **videos**, slideshows, token displays, web pages — screen by screen, per area /
floor, or on every screen at once. One server hosts many **customers** (multi-tenant SaaS) with plans, invoices,
resellers and white-label branding; each customer manages its own **screens**.

*Tamara business na darek TV / screen ne admin panel thi remotely control karo — content push karo,
screen-wise schedule karo, emergency message moklo, TV reboot/update karo.*

```
 Admin Panel (PC / tablet / phone)
        │  HTTPS
        ▼
 PHP 8 REST API  ──►  MySQL / MariaDB
        ▲
        │  poll every 5–10 s (hash-based, content only sent when it changes)
        │
 Android TV app / web player (each screen)  ── offline cache: keeps showing the last content without internet
```

| Part | Folder | Tech |
|------|--------|------|
| Server: admin panel + REST API + installer + auto-updater | [`hotelcast/`](hotelcast) | PHP 8.1+, MySQL 8 / MariaDB 10.6, Apache, Bootstrap 5, vanilla JS — no Composer, no Node |
| Android TV app | [`android/`](android) | Kotlin, ExoPlayer 2.19, Retrofit, OkHttp, Glide, WorkManager — min SDK 21, target 34 |
| Documentation | [`docs/`](docs) | Install guide, TV setup, admin guide, API, developer guide (tenancy + extension points), security, test report |

## What's new in 2.9.4 — your credit line on every TV

| Change | Where |
|---|---|
| **Platform credit line**: a Gujarati + English line with your mobile number ("This digital TV system is made by … — call …") at the end of the ticker bar of every screen of every customer, also on screens without a ticker. Only the Super Admin can edit or switch it off; customers, resellers and TVs cannot change, hide or remove it. No TV app update needed | Super Admin → Platform settings → TV credit line · `docs/modules/platform_credit.md` |

## What's new in 2.9.3 — Live darshan for every customer

| Change | Where |
|---|---|
| **Live darshan library**: the Super Admin sets the Shri Dwarkadhish live link (or any other live stream / YouTube live) once — typed or copied from a customer's existing "Live Darshan" item. With *Add to every customer automatically* every existing and every new customer gets it in the Content Library, ready to assign to screens; otherwise customers add it with one click from Templates → Live darshan. Changing the link updates every customer's copy and all their TVs on the next poll (renamed copies keep their name) | Super Admin → Live darshan · Templates → Live darshan · `docs/modules/live_channels.md` |

## What's new in 2.9.2 — download the TV app from the website

| Change | Where |
|---|---|
| **"Download the TV app" on the website**: a section on the front page (en / gu / hi) with the version, size and a *Download APK* button, plus step-by-step install on the TV with the short address `<your site>/app` to type in the TV's Downloader app. Always the newest Super Admin release rolled out to *all customers* (a release for selected customers is never public); hidden when there is none. Resume supported, downloads counted | Front page → TV app · `app/index.php` · Super Admin → APK Manager |

## TV app 2.6.2 — direct live links play on the TV (no more "thin line")

TV app **2.6.2** (versionCode 16); the server stays 2.9.1. Upload the APK in Super Admin → APK Manager.

| Fix | Detail |
|---|---|
| **Direct links play in the native player** | A live link (`.m3u8`, `.mpd`, `rtsp://`, `rtmp://`, `.mp4`/`.ts` file) saved as *Web page* or *Video* used to open in the browser view (black screen with one thin bar) or be downloaded as a video file. It now plays in the video player like a *Live stream* item (`MediaUrls.kt`) |
| **Links without .m3u8** | `https://host/live/darshan` style links are tried as HLS, then DASH, when the player does not recognise them |
| **RTMP** | `rtmp://` links play (ExoPlayer RTMP extension) |
| **Thin-line picture** | A stream that reports a broken picture size (camera aspect ratio) fills the screen instead of being drawn as a line |
| **Slow lines** | A stream gets 60 s to start (2.6.1 reloaded it after 20 s for ever on a slow line); repeated reloads back off up to 2 min |
| **Wrong TV / stream clock** | Jumps to live that do not reduce the delay are stopped after 2 tries (2.6.1 could seek every 15 s) |
| **Decoders / RTSP** | Decoder fallback for cameras the first decoder cannot play; RTSP retries alternate UDP / TCP |
| **Diagnostics** | Player errors are written to the TV's error log (Support → TV logs), links without query strings / passwords |

## What's new in 2.9.1 — TV app updates only from the Super Admin

| Change | Where |
|---|---|
| **APK updates are Super Admin only**: the customers' APK Manager is gone (menu item removed, `admin/apk.php` → Super Admin → APK Manager, 403 for everyone else), the `apk.manage` permission belongs to the Super Admin only (custom roles can't get it), the plan feature "TV app updates" is removed, `UPDATE_APP` can only be sent by the Super Admin, and customers never see "Update available" hints. Old customer uploads are ignored — every TV gets the Super Admin's release (all customers or the selected ones) | Super Admin → APK Manager |

## What's new in 2.9 — live video stays in sync, customizable side menu

Server 2.9.0 (migration 036: `users.menu_prefs`) + TV app **2.6.1** (versionCode 15).

| Feature | Where |
|---|---|
| **Live video never falls behind**: the TV checks every 15 s how far a live stream is behind live and jumps back when it is more than the maximum delay (default 60 s, max 120 s); stalled/frozen streams reload; a periodic re-sync runs every N minutes (Off / 2 / 5 / 10 / 15 / 30, default 5) without a black screen. YouTube live pages are re-synced and reloaded too. The web player does the same with hls.js / native HLS. A source that is itself delayed cannot be beaten | Settings → TV & Display → Live video · TV app 2.6.1 · `docs/modules/live_sync.md` |
| **Customizable side menu**: hide/show and reorder sidebar items (drag & drop or ↑↓). Business default in Settings → Menu; personal **My menu** in Profile (also for the Super Admin / reseller consoles). Hidden items stay reachable in a "Hidden items" group; Dashboard and Settings can't be hidden; permissions and plans are never widened | Settings → Menu · Profile → My menu · `docs/modules/menu_settings.md` |

## What's new in 2.8 — email that really works: SMTP, forgot password, invites, welcome mail

Server only (`version.json` 2.8.0, migration 035; the TV app stays 2.6.0). Guide: [docs/modules/email.md](docs/modules/email.md).

| Feature | Where |
|---|---|
| **Reliable e-mail**: own SMTP client (STARTTLS 587 / SSL 465, AUTH PLAIN / LOGIN, certificate checked) with PHP `mail()` as fallback; proper MIME (text + HTML, UTF-8 Gujarati / Hindi subjects, Message-ID), header-injection safe. **Every** mail of the platform goes through it, in a branded layout (white-label: customer mails carry the customer's brand) | `core/Mailer.php` · `core/MailTemplate.php` |
| **Super Admin → Platform settings → Email (SMTP)**: server, port, encryption, username, password (stored encrypted, never shown), From email / name, presets for Gmail / Hostinger / Zoho / cPanel, **Send test email** with the exact SMTP error, **Email log** (last 200 sends, no contents) | `admin/platform_settings.php?tab=email` |
| **Forgot password?** on every login page: by email or username, same neutral answer for every request, 60-minute single-use link (only a hash stored), rate limits per IP / account, new password logs out every device, "password changed" mail. All roles | `admin/forgot_password.php` · `admin/reset_password.php` · `core/PasswordReset.php` |
| **Login with email or username** (case-insensitive, spaces trimmed); email addresses stay unique | `admin/login.php` · `core/Auth.php` |
| **Invite links**: new users get "set your password" (72 h) instead of a shared password — Users, Customer 360, new customer, platform admins, resellers, chain admins (setting a password directly still possible) | user forms |
| **Sign-up**: verification code and a **welcome mail** (login link, username / email, trial days, how to connect the first TV) in the chosen language; a failed send is shown to the visitor ("could not send — try again / contact support") and logged instead of failing silently; resend with a 60-s countdown | `signup.php` · `core/Signup.php` |

**After updating:** Super Admin → Platform settings → **Email (SMTP)** → fill in your mailbox (Gmail: App Password)
→ **Send test email** → **Save settings**. Until then mails still use PHP `mail()` as before.

## What's new in 2.7 — Super Admin APK Manager, forced TV app update on start (TV app 2.6.0)

| Feature | Where |
|---|---|
| **Super Admin → APK Manager**: upload the TV app **once for the whole platform**. Version name / code, package (`com.hotelcast.tv`) and signing certificate are read from the APK itself (no aapt); wrong package, unsigned or wrongly signed builds and versions that are not newer are refused. Per release: **Required update (force)** (default on), release notes, roll-out to **all customers** or **selected customers**; list with Latest / Required badges, downloads, how many TVs run each version, delete (never the latest). **"Update all TVs now"** sends the update to every online Android TV with an older app (web players never) and reports how many got it | Super Admin console → Devices & content → APK Manager · `admin/platform_apk.php` · `core/AppReleases.php` · `core/ApkInfo.php` · migration 034 |
| Precedence: a TV gets the **highest versionCode** of {platform releases rolled out to its customer, its customer's own APK Manager releases}; the customer APK Manager keeps working for plans that include it. Overview "Outdated app", Devices & screens "Needs update" and "Update app" use the same rule | [docs/modules/apk_manager.md](docs/modules/apk_manager.md) |
| **TV app 2.6.0 — forced update on start**: every start of the app asks the server (`GET api/device/app-version`, also `app_update` in each poll) before playing; while a required newer version exists the TV shows a full-screen **"Update required"** screen (EN / ગુજરાતી / हिन्दी, progress bar) and installs it (silently on device-owner TVs, else via the system installer). It can't be dismissed and never plays the old version; clear errors (no space, download failed, installs blocked → how to allow, signature mismatch) with "Try again" + automatic retry every 30 s. A TV that is already running keeps playing and updates at its next start (the APK is pre-downloaded in the background). Offline start without any known update → plays its cached content | `android/` · `release/KrishnaCloud-TV-2.6.0.apk` |

**How existing 2.5.0 TVs get it:** upload `KrishnaCloud-TV-2.6.0.apk` in Super Admin → APK Manager (Required on)
and press **"Update all TVs now"** once — 2.5.0 TVs install it through the normal update push (`UPDATE_APP`).
From then on every app start is gated: a TV can't be used with an old version again.

## What's new in 2.6.1 — public landing page, TV transfer only from the Super Admin console, logs

Server only (the TV app stays 2.5.0).

| Feature | Where |
|---|---|
| **Public landing page at the site root** (`index.php`, no login): gradient hero with the white-label name / logo, "who is it for" cards (temples, hotels, hospitals & clinics, schools & coaching, restaurants & cafés, shops & showrooms, offices & factories, hostels & resorts), every feature group (screens & TVs, content, the display apps, scheduling, emergency & announcements, video walls & sync, analytics & proof of play, teams & roles, languages, security, plans & modules, hotel pack, devices it works on), "how it works" in 5 steps, plans, FAQ and a final call to action. English / ગુજરાતી / हिन्दी (`?lang=`, remembered in a cookie, else the browser language); fully responsive (360 px – desktop), light and dark, reduced-motion aware, local assets only (no CDN), strict CSP (no inline script), canonical / hreflang / Open Graph / SoftwareApplication JSON-LD | `/` · `core/Landing.php` · `assets/landing/` · `lang/{gu,hi}_landing.php` |
| Everything on it is **driven by the platform**: "Start free trial" only when online sign-up is on (`Signup::enabled()`), "Watch live demo" only when the public demo is on, WhatsApp / call / e-mail from Platform settings → support phone / e-mail (WhatsApp only for a number in +country format), **plan cards read from the active rows of the plans table** (price per screen / month, screen / user / storage limits, included modules or "all modules, except …"; no active plan → "Contact us for pricing"). Live numbers (screens, businesses) are aggregate counts only, cached 10 min and shown from 10 upwards — no customer name is ever shown | Platform → Settings / Sign-ups / Demo / Plans |
| Logged-in visitors see **"Go to dashboard"** instead of "Login" (no automatic redirect any more); a server that is not installed still goes to the installer | `/` |
| **Transfer a TV to another customer only from the Super Admin console** — the transfer button / bulk action was removed from the customer's Screens page | Super Admin → All screens / Customer 360 |
| **Logs**: the Super Admin's work inside a customer workspace no longer appears in the customer's logs (still in Super Admin → Audit logs); logs can be cleared (customer Admin: own logs per tab, all or older than 30 / 90 / 365 days; Super Admin: audit log, error / update logs) | Logs · Super Admin → Audit logs |
| **Console pages stay in the console**: Auto-Update, platform settings, Support & logs and every Super Admin page opened while a customer workspace is open show the Super Admin console — never the customer's name, banner, plan notice or footer. Server-wide error / update logs moved from the customer's Logs page to Super Admin → Support & logs → Server logs (view + clear) | Super Admin console |

## What's new in 2.6 — three separate panels, Super Admin console, customer archive / delete

Server only (the TV app stays 2.5.0). Design notes and research: [docs/modules/panels.md](docs/modules/panels.md); owner's specification: [docs/SPEC_SAAS.md](docs/SPEC_SAAS.md).

| Feature | Where |
|---|---|
| **Three panels with their own look**: the **Super Admin console** (dark indigo, "Super Admin" badge, platform menu only — no customer modules), the **Reseller panel** (teal, own overview / customers / screens / plans / invoices / support) and the **Customer workspace** (the customer's branding; never a platform or reseller item). `core/Panel.php` decides the panel from the role; permissions stay server-side | every admin page |
| **Super Admin dashboard**: KPI tiles (customers, active / suspended / expiring, TVs online / offline / outdated / health warnings, users, open sign-ups, unpaid invoices, revenue, resellers, pool), "Needs attention" alerts, **device errors with severity**, trends (customer growth, TVs by status, customers by plan), recent activity across customers, platform switches (online sign-up, platform registration) | Super Admin → Dashboard |
| **Global search** in the header: customers, screens / TVs (name, device ID, IP), users (e-mail, username), resellers — limited to what the user may see; customer users get 403 | header search box · `platform_search.php` |
| **Customer 360**: Summary · Plan & features (**switch every feature on / off**, limits and expiry inline) · Screens (commands, transfer, update, revoke, screen on / off) · Users (create, role, reset password, enable / disable) · Content snapshot · Billing (invoices, licenses, extend validity) · Activity · Settings (status switch, registration key, chain, branding, archive, delete). Everything routine without opening the customer | Super Admin → Customers → Manage |
| **One-click switches** with CSRF and audit log: customer active / suspended, feature per customer, user active, screen on / off, plan active, reseller active, sign-up open, platform registration | console pages · `ajax.php?action=platform_toggle` |
| **"Open customer workspace"** (impersonation) is explicit: a striped violet banner *"You are managing customer X as Super Admin — Exit workspace"*, the customer's own theme and sidebar, every action logged in the customer's log | Customer 360 / lists |
| **Archive and delete customers** (spec §50): *Archive* (suspended, hidden from the list, restorable) is the default list action; *Delete permanently* needs the typed customer name and removes every row of every table with `hotel_id`, uploaded files, APKs, live-view frames and caches, logs out its users and rejects its TVs (401) — invoices are kept for accounting (`customer_name` snapshot, migration 032) | Customers list · Customer 360 → Settings |
| **Console pages from the spec**: Content overview (what every customer has uploaded / assigned), Reports (growth, revenue, plan / status / reseller distribution, TVs per customer, CSV), Audit logs across all customers (filters, CSV); customer menu reordered (Dashboard, Screens, Locations & groups, Content, Playlists, Schedules, …, Users, Settings, **Subscription** with TRIAL / ACTIVE / EXPIRING / EXPIRED / SUSPENDED state) | Super Admin → Insight · Customer → Subscription |
| A module that is off in the plan answers **"This feature is not available in your current plan."** on pages, ajax and API | 403 responses |
| Every new string in ગુજરાતી and हिन्दी (`lang/gu_panels.php`, `lang/hi_panels.php`) | language menu |

## What's new in 2.5.1 — all TVs on Screens & TVs, transfer a TV with everything

Server only (the TV app stays 2.5.0).

| Feature | Where |
|---|---|
| **Screens & TVs → All customers**: the Super Admin sees every TV of every customer — including the customers of resellers — on Screens & TVs, with a view switch "This customer (…)" \| "All customers (N TVs)" (default All customers, remembered), customer column with a link to the customer details, search, customer / status filters, "screens without TV" and pagination. Resellers see their own customers; customer users never see the switch | Screens & TVs · [platform_screens.md § 7](docs/modules/platform_screens.md) |
| **Transfer to another customer — everything**: ⇄ button on every TV (both views, TV detail page, All screens; bulk via checkboxes). Besides the TV (token kept, no setup on the TV) it **copies** the screen details (name / ID, area / floor, PIN, USB / HDMI-CEC mode, power-off times, device schedules) and the content (playlist, media files copied into the new customer's storage, layouts, tickers, scheduled content) to the target screen. The old customer keeps its originals; the target's TV and storage limits are checked; on any error nothing is left behind. Result: "Copied: 1 playlist, 12 media files, 1 ticker; Not copied: …" | Screens & TVs, Platform → All screens · [platform_screens.md § 2b](docs/modules/platform_screens.md) |

## What's new in 2.5 — plans, roles, all screens, new name

| Feature | Where |
|---|---|
| **New name: Krishna Cloud TV Management** — a general digital-signage SaaS. In the UI "Hotel" is now **Customer** (platform) / **Business** (customer side) and "Room" is **Screen** (screen name / ID + optional area / floor). Hotel wording remains only in the optional **Hospitality** module (guests, room service, PMS, feedback, local guide). Database, API and JSON names are unchanged | everywhere · [terminology.md](docs/modules/terminology.md) |
| **Plans & features**: every module belongs to a feature; plans (Basic / Business / Hospitality …) switch feature groups on or off per customer, plus per-customer add / remove overrides. Pages, menus, API routes, TV extensions and permissions follow the plan | Platform → Plans, Customer details · [plans_features.md](docs/modules/plans_features.md) |
| **Custom roles (RBAC)**: copy a built-in role, pick permissions from a matrix (hidden when the plan lacks the feature), assign it to users; escalation-safe | Admin → Roles · [roles.md](docs/modules/roles.md) |
| **All screens**: every TV of every customer in one table with filters, bulk commands, **move a TV** to another customer / screen, an **unassigned pool** for TVs registered with the platform key, and a **customer details** page (TVs, users, plan, features) | Platform → All screens · [platform_screens.md](docs/modules/platform_screens.md) |
| **Hindi admin panel**: the admin language menu now offers English / ગુજરાતી / हिन्दी (main pages translated, the rest falls back to English) | language menu |
| Demo data is a general business ("Krishna Showroom": Entrance, Counter 1 …); hospitality demo data only when the demo customer's plan has the Hospitality features | Platform → Demo |
| TV app 2.5.0 (versionCode 13): new name ("Krishna Cloud TV" on the launcher), "Screen name / ID" instead of room number, QR setup wording | [android/README.md](android/README.md) |

## What's new in 2.4 — features 26–50

| # | Feature | Docs |
|---|---|---|
| 26–30 | Air quality + coastal/ferry warning, Panchang + Choghadiya (offline), festival countdown, birthday wall, Google reviews | [widgets_26_30.md](docs/modules/widgets_26_30.md) |
| 31–35 | Calendar (drag & drop), content approval, start/expiry dates, playlist time windows, holiday calendar | [scheduling.md](docs/modules/scheduling.md) |
| 36–37 | Video wall (up to 4×4) and synchronized playback | [video_wall_sync.md](docs/modules/video_wall_sync.md) |
| 38–40, 43, 47, 49 | Volume / input / restart / bell schedules, spoken announcements, presence sensors, proof-of-play report | [device_schedules.md](docs/modules/device_schedules.md) |
| 41, 42, 44, 48, 50 | Live screen view, USB/offline mode, TV health, text-to-speech, HDMI-CEC (boxes) | [device_features.md](docs/modules/device_features.md) |
| 45–46 | Web player for Smart-TV browsers / PCs, Fire TV & Raspberry Pi setup | [web_player.md](docs/modules/web_player.md) |

## What's new in 2.3 — 25 new features

| # | Feature | Where |
|---|---|---|
| 1 | Restaurant menu board (sold-out switch, today's special, veg/non-veg, dayparting) | Apps → Menu board · [menu_board.md](docs/modules/menu_board.md) |
| 2, 5 | Token / queue system for hospitals, clinics, banks, offices (NEXT/RECALL, chime + voice, tickets, phone self-service) | Apps → Token display · [queue.md](docs/modules/queue.md) |
| 3 | School / office notice board | Apps → Notice board |
| 4, 6, 7, 8 | Shop offers with countdown, gym/class schedule, bus/rail/airport departures, factory KPI dashboard (+ machine push API) | [business_apps.md](docs/modules/business_apps.md) |
| 9, 10 | Real-estate showcase, wedding/event welcome | [content_apps.md](docs/modules/content_apps.md) |
| 11, 12 | Drag & drop slide designer (14 templates), PDF → slides import | Content → Design a slide / Import PDF · [designer_pdf.md](docs/modules/designer_pdf.md) |
| 13 | Split-screen layouts (up to 6 zones) | Content → Split screen · [layouts.md](docs/modules/layouts.md) |
| 14, 16, 19 | Google Sheet live table, Instagram/Facebook wall, phone photo album (+ guest upload link) | [content_apps.md](docs/modules/content_apps.md) |
| 15 | YouTube playlists and channels | Content → YouTube |
| 17, 18 | Countdown, QR (URL / UPI / WhatsApp / Wi-Fi) | Apps |
| 20 | 12 themes (Diwali, Navratri, Janmashtami, wedding …) + bundled Gujarati/Hindi fonts | every app · [display_apps.md](docs/modules/display_apps.md) |
| 21–25 | Gold/silver rates, stock market, cricket, currency, train/flight status (manual or API key) + ticker placeholders `{gold_24k}` `{usd_inr}` … | [data_feeds.md](docs/modules/data_feeds.md) |
| 26–30 | Air quality + rain / heat / sea-ferry warnings, offline panchang + choghadiya, festival calendar with countdown, birthday / anniversary wall (consent, CSV), Google reviews | Apps · Festivals · Birthdays · [widgets_26_30.md](docs/modules/widgets_26_30.md) |

## What's new in 2.2

| Feature | Where |
|---|---|
| **Ticker bar per TV / group / all**: own text, colours, speed, font size, height, top or bottom, date/time windows. The video shrinks so the bar never covers it | Admin → **Ticker** · [docs/modules/ticker_bar.md](docs/modules/ticker_bar.md) |
| **Per-user TV access**: the Admin gives each Manager / Staff / Reception user "All TVs" or only chosen groups / screens | Admin → **Users** · [docs/modules/user_access.md](docs/modules/user_access.md) |
| **SaaS role names**: Super Admin (Platform) → Admin (per customer) → Manager / Staff / Reception | everywhere |
| **Hotel chains hidden by default** (Platform settings → Features to turn them on) | Platform settings |
| TV app 2.1.1: QR setup works on old TVs (bundled root certificates, wrong-clock handling, connection diagnostics) | TV app |

## Features

**TV app** — auto-start on boot · full-screen kiosk (HOME launcher, lock-task when device-owner) · image
slideshow with fade/slide transitions · video (loop/mute) · live HLS/RTSP/DASH streams with auto-reconnect ·
HTML timetable with the current darshan highlighted · marquee or full-screen announcements · any URL / YouTube ·
clock, weather, logo and ticker overlays · emergency override · offline cache of content and media ·
remote reboot, clear-cache, screen on/off, silent APK update · PIN-protected settings · English + ગુજરાતી.

**Admin panel** — live dashboard · screens with online/offline, IP, app version, Wi-Fi · area/floor/zone groups ·
content library (uploads with resize/compression, streams, URLs, announcements, timetable builder, HTML) ·
drag-and-drop playlists · push now / schedule / daily time windows / repeat days · emergency broadcast ·
calendar · users with Super Admin / Manager / Staff roles · APK manager · logs & reports with CSV export ·
settings · GitHub auto-update with backup + auto-rollback · TV-simulator preview of any content or screen.

**Multi-customer platform (2.0)** — one server hosts many customers, each with its own login and fully
isolated data · platform admin: customers (create / suspend / enter), plans with TV limits, monthly
invoices with tax (manual payments, overdue reminders, auto-suspend & reactivation), resellers with
commission reports, license keys for self-hosted installs · white-label branding (platform → reseller →
customer) on login, admin panel, invoices and TVs · roles Platform Admin / Reseller / Super Admin /
Manager / Staff / Reception · extension points for modules ([docs/DEVELOPER.md](docs/DEVELOPER.md)).

## What's new in 2.1

| # | Feature | Where |
|---|---------|-------|
| QR | Add a TV with a QR code — the TV shows a QR, staff scan it with a phone, pick the room, done (no typing on the TV) | Admin → Add TV (QR), `docs/modules/qr_setup.md` |
| 17 | Online sign-up with 14-day free trial, reminders, upgrade → invoice | `signup.php`, Platform → Sign-ups, `docs/modules/signup_demo.md` |
| 21 | Public demo hotel + TV simulator, private client demos (7 days) | `demo.php`, Platform → Demo |
| 19 | Ad marketplace: local businesses book TV ads, UPI/bank payment, hotel revenue share, proof-of-play | `/advertise/`, Admin → Marketplace, `docs/modules/ad_marketplace.md` |
| 20 | Hotel chain dashboard: all hotels in one view, publish content & broadcast to many hotels | Admin → Chain, `docs/modules/hotel_chains.md` |

## What's new in 2.0

| # | Feature | Where |
|---|---------|-------|
| 18–22 | Multi-hotel SaaS, platform & reseller panels, plans/TV limits, license keys for self-hosted installs, manual invoices with auto-suspend, white-label branding | Admin → Platform, `docs/ADMIN_GUIDE.md`, `docs/INSTALL.md` |
| 1, 6, 9, 10 | Guest front desk, check-in mode (vacant TVs off), personal welcome card, checkout reminder, PMS API + webhook | Admin → Front desk, `docs/modules/guests_services.md` |
| 2, 3, 8 | Guest phone web app via TV QR: room service, requests, feedback (Google review) + live staff alerts | `/g/<token>`, Admin → Orders |
| 11, 17 | Sponsor ads with impression reports, analytics (plays, uptime, hours ON, electricity, services) | Admin → Ads, Analytics, `docs/modules/ads_analytics_templates.md` |
| 7, 12 | 28 ready-made templates (festivals, notices, temple, local guide) — replaces #13 AI for now | Admin → Templates |
| 4, 5, 15, 16 | TV guest menu (QR, Live TV, HDMI, cast), volume + night limit, screenshots, messages | Admin → TV controls, `docs/modules/pwa_support_devices.md` |
| 14 | Admin as installable phone app (PWA) with web-push notifications | Admin → Notifications |
| 23 | Windows bulk TV setup tool | `tools/windows/`, Admin → Screens & TVs → Download setup file |
| 24 | Support: TV logs, crash reports, platform support dashboard | Admin → Support |

Developer extension points: `docs/DEVELOPER.md`. Full 2.0 contract: `docs/V2_SPEC.md`.

## Quick start

1. **Server** — upload `dist/hotelcast-2.5.0.zip` (built by `tools/build-release.sh`) to your hosting, extract, open
   `https://your-domain/hotelcast/install/` and follow the 7-step wizard → [docs/INSTALL.md](docs/INSTALL.md)
2. **TVs** — install `android/release/KrishnaCloud-TV-2.6.0.apk` on each TV (USB pen-drive or `adb`), open it,
   scan the QR code with your phone (or enter server address + screen name / ID + registration key) → [android/README.md](android/README.md)
3. **Use it** — Admin → Content → add content → Broadcast → choose screens → *Push now* → [docs/ADMIN_GUIDE.md](docs/ADMIN_GUIDE.md)

## Auto-update (GitHub)

Admin → **Auto-Update**: save repository URL, branch, app folder (`hotelcast`) and a fine-grained
Personal Access Token (Contents: read) once. Then:

* **Check for Update** — latest version, commit message, date, changed files and changelog.
* **Update Now** — full backup (files + MySQL dump → `backups/backup_YYYY-MM-DD_HH-MM.zip`) → download →
  PHP syntax check of every file → install (never touching `.env`, `config.php`, `uploads/`, `storage/`,
  `backups/`, `logs/`) → numbered SQL migrations (tracked in `schema_migrations`) → cache/opcache clear →
  health check → **automatic rollback** of files and database on any error → log saved.
* **History** with per-row rollback, manual restore of any backup, backup download/upload.

To publish a new server release: bump `hotelcast/version.json`, add `hotelcast/migrations/00N_name.sql`
if the schema changes, push to the branch. TV app releases: upload the APK in Admin → APK Manager →
*Push App Update*.

## Repository layout

```
hotelcast/            Server application (this is what you upload)
  admin/              Admin panel pages (+ ajax.php, ajax_update.php)
  api/                REST API front controller (/api/...)
  install/            One-click installer (auto-deleted after use)
  core/               PHP classes: DB, Auth, Csrf, ContentManager, ContentResolver, Broadcaster,
                      DeviceManager, Scheduler, Updater, Backup, Migrator, HealthCheck, …
  migrations/         001_init.sql, 002_… (run automatically by installer/updater)
  lang/               gu*.php / hi*.php — Gujarati and Hindi translations
  assets/             CSS/JS + vendored Bootstrap, icons, SortableJS, FullCalendar, hls.js
  uploads/ backups/ logs/ storage/   runtime data (protected, never overwritten)
  tests/              PHPUnit unit + integration tests, load test
  version.json        {"version":"1.0.0","commit":"…","date":"…"}
android/              Android Studio project (Kotlin) + release/KrishnaCloud-TV-2.6.0.apk
docs/                 INSTALL, ADMIN_GUIDE, API, SECURITY, TEST_REPORT
tools/build-release.sh  builds dist/hotelcast-<version>.zip
```

## Development & tests

```bash
# PHP tests (needs a MySQL/MariaDB test database; it is wiped on every run)
cd hotelcast
HC_TEST_DB_HOST=127.0.0.1 HC_TEST_DB_NAME=hotelcast_test HC_TEST_DB_USER=hctest HC_TEST_DB_PASS=… phpunit -c phpunit.xml

# Load test against a running installation (simulates 80 TVs)
php tests/load/load_test.php --url=https://your-domain/hotelcast/ --key=REGISTRATIONKEY --tvs=80 --duration=120

# Local dev server (emulates the .htaccess routing)
php -S 127.0.0.1:8080 -t hotelcast hotelcast/tests/router.php

# Android
cd android && ./gradlew testReleaseUnitTest lintRelease assembleRelease
```

Results: [docs/TEST_REPORT.md](docs/TEST_REPORT.md). Security design: [docs/SECURITY.md](docs/SECURITY.md).
API reference: [docs/API.md](docs/API.md).

## ગુજરાતી સારાંશ

Krishna Cloud TV Management થી મંદિર, દુકાન, શોરૂમ, રેસ્ટોરન્ટ, હૉસ્પિટલ, શાળા, ઑફિસ, ફેક્ટરી કે હોટેલની
દરેક સ્ક્રીન (Android TV) ને એક જ બ્રાઉઝર પરથી કંટ્રોલ કરો: લાઇવ દર્શન, દર્શન સમય, મેનુ, જાહેરાતો, ઓફર
અને વિડિયો — તરત જ બધી સ્ક્રીન પર. એક સર્વર પર ઘણા ગ્રાહકો (customers) — દરેકની પોતાની સ્ક્રીન. સર્વર પર
ફાઇલો અપલોડ કરો, `/install` ખોલો અને સ્ટેપ ફોલો કરો. એડમિન પેનલ અંગ્રેજી, ગુજરાતી અને હિન્દીમાં ઉપલબ્ધ છે.

**2.7 — APK મેનેજર:** સુપર એડમિન કન્સોલ → APK મેનેજરમાં નવી એપ એક જ વાર અપલોડ કરો ("ફરજિયાત અપડેટ" ચાલુ) અને
"બધા TV હમણાં અપડેટ કરો" દબાવો. ચાલુ TV ચાલતું રહે છે, પણ એપ ફરી ખુલે ત્યારે પહેલા અપડેટ થાય છે — જૂનું વર્ઝન
વાપરી શકાતું નથી ("અપડેટ ફરજિયાત છે" સ્ક્રીન). જૂના 2.5.0 TV ને 2.6.0 એક વાર "બધા TV હમણાં અપડેટ કરો" થી મળે છે.
