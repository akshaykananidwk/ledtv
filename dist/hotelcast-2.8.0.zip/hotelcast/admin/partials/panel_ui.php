<?php
declare(strict_types=1);

/**
 * 2.6 panels (docs/modules/panels.md) — small UI pieces shared by the Super Admin console and the
 * Reseller panel: KPI tiles, one-click switches (admin/ajax_platform.php), alert lists, empty states,
 * the "Open customer workspace" button. Only renders escaped HTML; permission checks stay in the pages.
 */

require_once __DIR__ . '/common.php';

if (defined('HC_PANEL_UI')) {
    return;
}
define('HC_PANEL_UI', true);

/** One KPI tile. $tone: '' | 'success' | 'warning' | 'danger' (danger/warning only when $value > 0 makes sense). */
function panel_kpi(string $label, int|string $value, string $icon, string $href = '', string $sub = '', string $tone = '', string $key = ''): string
{
    $tag = $href !== '' ? 'a' : 'div';
    return '<' . $tag . ($href !== '' ? ' href="' . e($href) . '"' : '') . ' class="kpi' . ($tone !== '' ? ' kpi-' . e($tone) : '') . '"' . ($key !== '' ? ' data-kpi="' . e($key) . '"' : '') . '>'
        . '<span class="kpi-label"><i class="bi ' . e($icon) . '"></i> ' . e($label) . '</span>'
        . '<span class="kpi-value">' . e((string) $value) . '</span>'
        . ($sub !== '' ? '<span class="kpi-sub">' . e($sub) . '</span>' : '')
        . '</' . $tag . '>';
}

/**
 * One-click switch bound to ajax.php?action=platform_toggle. $kind + $target identify the thing
 * (see admin/ajax_platform.php); $on = current state. Optional confirm text when switching OFF.
 */
function panel_switch(string $kind, int|string $target, bool $on, string $label = '', string $confirmOff = '', string $confirmOn = '', array $extra = [], bool $disabled = false): string
{
    $id = 'sw_' . preg_replace('/[^a-z0-9]+/i', '_', $kind . '_' . $target);
    $attrs = '';
    foreach ($extra as $k => $v) {
        $attrs .= ' data-' . e((string) $k) . '="' . e((string) $v) . '"';
    }
    return '<label class="hc-switch form-check form-switch m-0" data-platform-switch data-kind="' . e($kind) . '" data-target="' . e((string) $target) . '"'
        . ($confirmOff !== '' ? ' data-confirm-off="' . e($confirmOff) . '"' : '') . ($confirmOn !== '' ? ' data-confirm-on="' . e($confirmOn) . '"' : '') . $attrs . '>'
        . '<input class="form-check-input" type="checkbox" role="switch" id="' . e($id) . '"' . ($on ? ' checked' : '') . ($disabled ? ' disabled' : '') . '>'
        . ($label !== '' ? '<span class="hc-switch-label" data-switch-label data-on="' . e(__('On')) . '" data-off="' . e(__('Off')) . '">' . e($label) . '</span>' : '')
        . '</label>';
}

/** Alerts list (overview). $alerts: [['tone' => 'danger', 'icon' => 'bi-…', 'text' => '', 'href' => '', 'action' => '']]. */
function panel_alerts(array $alerts, string $allGood): string
{
    if (!$alerts) {
        return '<div class="hc-empty py-4" data-alerts-empty><i class="bi bi-check2-circle text-success"></i><p class="mb-0"><strong>' . e($allGood) . '</strong></p></div>';
    }
    $h = '<ul class="list-group list-group-flush hc-alerts" data-alerts>';
    foreach ($alerts as $a) {
        $tone = $a['tone'] ?? 'warning';
        $h .= '<li class="list-group-item"><i class="bi ' . e($a['icon'] ?? 'bi-exclamation-circle') . ' text-' . e($tone) . '"></i>'
            . '<div class="flex-grow-1 min-w-0"><div>' . e($a['text']) . '</div>' . (!empty($a['sub']) ? '<div class="small text-muted">' . e($a['sub']) . '</div>' : '') . '</div>'
            . (!empty($a['href']) ? '<a class="btn btn-sm btn-light border text-nowrap" href="' . e($a['href']) . '">' . e($a['action'] ?? __('Open')) . '</a>' : '')
            . '</li>';
    }
    return $h . '</ul>';
}

/** Empty state block. */
function panel_empty(string $icon, string $title, string $text = '', string $href = '', string $action = ''): string
{
    return '<div class="hc-empty"><i class="bi ' . e($icon) . '"></i><p class="mb-1"><strong>' . e($title) . '</strong></p>'
        . ($text !== '' ? '<p class="mb-2 small">' . e($text) . '</p>' : '')
        . ($href !== '' ? '<a class="btn btn-sm btn-primary" href="' . e($href) . '">' . e($action) . '</a>' : '') . '</div>';
}

/** "Open customer workspace" (impersonation) button: POST op=enter to $page. */
function panel_open_workspace(int $hotelId, string $page = 'platform_customer.php', string $size = '', string $next = ''): string
{
    return '<form method="post" action="' . e(admin_url($page)) . '" class="d-inline m-0">' . Csrf::field()
        . '<input type="hidden" name="op" value="enter"><input type="hidden" name="id" value="' . $hotelId . '">'
        . ($next !== '' ? '<input type="hidden" name="next" value="' . e($next) . '">' : '')
        . '<button class="btn btn-outline-primary' . ($size !== '' ? ' btn-' . e($size) : '') . '" title="' . e(__('Work inside this customer\'s panel (shown with a banner, logged).')) . '">'
        . '<i class="bi bi-box-arrow-in-right"></i> <span class="d-none d-sm-inline">' . e(__('Open customer workspace')) . '</span></button></form>';
}

/** Recent activity rows across customers (platform / reseller scope). */
function panel_recent_activity(?array $scope, int $limit = 15): array
{
    $w = '';
    $p = [];
    if ($scope !== null) {
        if (!$scope) {
            return [];
        }
        $in = [];
        foreach (array_values($scope) as $i => $hid) {
            $in[] = ':s' . $i;
            $p['s' . $i] = (int) $hid;
        }
        $w = ' WHERE a.hotel_id IN (' . implode(',', $in) . ')';
    }
    return DB::all('SELECT a.*, h.name AS hotel_name FROM activity_logs a LEFT JOIN hotels h ON h.id = a.hotel_id' . $w . ' ORDER BY a.id DESC LIMIT ' . max(1, $limit), $p);
}

/**
 * Confirmation modal for deleting a customer (Customers list / Customer 360). Opened by any
 * [data-delete-customer="<id>" data-name="<name>"] button; the form posts op=delete to
 * platform_customer.php and only submits when the typed name matches.
 */
function panel_delete_customer_modal(): string
{
    ob_start();
    ?>
    <div class="modal fade" id="hcDeleteCustomer" tabindex="-1" aria-hidden="true" data-delete-customer-modal>
      <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
        <form method="post" action="<?= e(admin_url('platform_customer.php')) ?>" data-delete-form>
          <?= Csrf::field() ?><input type="hidden" name="op" value="delete"><input type="hidden" name="id" value="0" data-delete-id>
          <div class="modal-header"><h5 class="modal-title text-danger"><i class="bi bi-exclamation-octagon"></i> <?= e(__('Delete customer')) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?= e(__('Close')) ?>"></button></div>
          <div class="modal-body">
            <p><?= e(__('Deleting a customer removes its users, screens, TVs, content, playlists, logs and invoices permanently. Its TVs return to the setup screen. This cannot be undone.')) ?></p>
            <label class="form-label" for="hcDelName"><?= e(__('Type the customer name to confirm:')) ?> <strong data-delete-name></strong></label>
            <input class="form-control" id="hcDelName" name="confirm_name" autocomplete="off" required data-delete-input>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-light border" data-bs-dismiss="modal"><?= e(__('Cancel')) ?></button>
            <button class="btn btn-danger" disabled data-delete-submit><i class="bi bi-trash"></i> <?= e(__('Delete customer')) ?></button></div>
        </form>
      </div></div>
    </div>
    <script>
    document.addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-delete-customer]');
      if (!b || !window.bootstrap) { return; }
      var m = document.getElementById('hcDeleteCustomer');
      m.querySelector('[data-delete-id]').value = b.getAttribute('data-delete-customer');
      m.querySelector('[data-delete-name]').textContent = b.getAttribute('data-name');
      var inp = m.querySelector('[data-delete-input]'); inp.value = '';
      m.querySelector('[data-delete-submit]').disabled = true;
      bootstrap.Modal.getOrCreateInstance(m).show();
      setTimeout(function () { inp.focus(); }, 300);
    });
    document.addEventListener('input', function (ev) {
      if (!ev.target.matches('[data-delete-input]')) { return; }
      var m = ev.target.closest('[data-delete-customer-modal]');
      m.querySelector('[data-delete-submit]').disabled = ev.target.value.trim() !== m.querySelector('[data-delete-name]').textContent.trim();
    });
    </script>
    <?php
    return (string) ob_get_clean();
}

/**
 * Lightweight inline bar chart (no JS library): $rows = [[label, value, ?tone]], horizontal bars scaled to the max.
 * $format: callable for the value text. Used by the Super Admin dashboard / reports (docs/SPEC_SAAS.md §5).
 */
function panel_bars(array $rows, ?callable $format = null, string $key = ''): string
{
    $max = 0;
    foreach ($rows as $r) {
        $max = max($max, (float) $r[1]);
    }
    if (!$rows) {
        return '<div class="hc-empty py-3"><i class="bi bi-bar-chart"></i><p class="mb-0 small">' . e(__('No data yet.')) . '</p></div>';
    }
    $h = '<div class="hc-bars"' . ($key !== '' ? ' data-chart="' . e($key) . '"' : '') . '>';
    foreach ($rows as $r) {
        $pct = $max > 0 ? (int) round((float) $r[1] * 100 / $max) : 0;
        $h .= '<div class="hc-bar-row"><span class="hc-bar-label" title="' . e((string) $r[0]) . '">' . e((string) $r[0]) . '</span>'
            . '<span class="hc-bar-track"><span class="hc-bar' . (!empty($r[2]) ? ' hc-bar-' . e((string) $r[2]) : '') . '" style="width:' . $pct . '%"></span></span>'
            . '<span class="hc-bar-value">' . e($format ? (string) $format($r[1]) : (string) $r[1]) . '</span></div>';
    }
    return $h . '</div>';
}

/** Stacked status bar: $parts = [[label, value, tone]] in one 100 % bar with a legend. */
function panel_stacked(array $parts, string $key = ''): string
{
    $total = array_sum(array_map(static fn ($p) => (float) $p[1], $parts));
    $h = '<div class="hc-stacked"' . ($key !== '' ? ' data-chart="' . e($key) . '"' : '') . '><div class="hc-stacked-bar">';
    foreach ($parts as $p) {
        $pct = $total > 0 ? (float) $p[1] * 100 / $total : 0;
        if ($pct > 0) {
            $h .= '<span class="hc-bar-' . e((string) $p[2]) . '" style="width:' . round($pct, 1) . '%" title="' . e((string) $p[0]) . ': ' . e((string) $p[1]) . '"></span>';
        }
    }
    $h .= '</div><div class="hc-stacked-legend">';
    foreach ($parts as $p) {
        $h .= '<span><i class="hc-dot hc-bar-' . e((string) $p[2]) . '"></i> ' . e((string) $p[0]) . ' <strong>' . e((string) $p[1]) . '</strong></span>';
    }
    return $h . '</div></div>';
}

